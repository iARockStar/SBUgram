package other;

import server.*;

/**
 * this class is just useless. should have user boolean instead -_____-.
 */
public enum ApprovedType {
    APPROVED,
    NOT_APPROVED
}
